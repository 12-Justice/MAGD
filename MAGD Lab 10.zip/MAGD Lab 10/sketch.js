// initializing variables
let barColors = [];
let barHeights = [];
let scribble = new Scribble();

function setup() 
{
    // creating canvas and generating graph 
    createCanvas(600, 400);
    generateRandomBars();
}

function draw() 
{
    // drawing background and bar graph
    backgroundScribble();
    drawBarGraph();
}

// generating random graphs for any key press 1-9 (it's fun to slide across the keyboard)
function keyPressed() 
{
    if (key >= '1' && key <= '9') 
    {
        generateRandomBars();
    }
}

// function that determines the bar colors and sizes based on random sets
function generateRandomBars() 
{
    barColors = Array.from({length: 10}, () => color(random(255), random(255), random(255)));
    barHeights = Array.from({length: 10}, () => random(15, height));
}

// function that creates the background
function backgroundScribble() 
{
    // setting background color
    background(200);

    // creating weird background with elements from the p5.scribble library
    scribble.scribbleRect(0, 0, 600, 400);
    scribble.scribbleEllipse(300, 200, 600, 400);
}

// function that draws the different bars
function drawBarGraph()
 {
    // looping through all 10 bars
    for (let i = 0; i < 10; i++) 
    {
        // setting fills based on pregenerated colors
        fill(barColors[i]);
        
        // drawing 10 bars across the screen with varrying sizes
        let barWidth = width / 10;
        let barX = i * barWidth;
        let barY = height - barHeights[i];
        rect(barX, barY, barWidth, barHeights[i]);

        // using bar values to set the scribbles
        scribbleBarFill(barX, barY, barWidth, barHeights[i]);
    }
}

// function that creates the changing scribbles
function scribbleBarFill(x, y, w, h) 
{
    // setting borders of the scribble to only inside the bars
    let xleft = x + 5;
    let xright = x + w - 5;
    let ytop = y + 5;
    let ybottom = y + h - 5;

    // setting coordinates for scribble fill borders
    let xCoords = [xleft, xright, xright, xleft];
    let yCoords = [ytop, ytop, ybottom, ybottom];

    // setting scribble line thickness
    strokeWeight(1);
    // setting scribble line color
    stroke(255);

    // filling bars with scribbles
    scribble.scribbleFilling(xCoords, yCoords, 3.5, 315);
}