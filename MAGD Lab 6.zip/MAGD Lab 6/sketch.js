// flick the mouse across the screen quickly and see what happens :)

// initializing variables
var num = 70;
var x = [];
var y = [];

// setup
function setup() {
  
  // setting defaults
  createCanvas(500, 500);
  background(0);
  noStroke();
  fill(255, 200);
  frameRate(60)
	
  // array setup
  for (var i = 0; i < num; i++) {

	x[i] = 0;
    y[i] = 0;
  }
}

function draw() {

  // copying array values back to front
  for (var i = num-1; i > 0; i--) {

	x[i] = x[i-1];
	y[i] = y[i-1];
  }
  
  // setting arrays based on mouse position
  x[0] = mouseX;
  y[0] = mouseY;
  
  for (var i = 0; i < num; i++) {

    // draw pumpkin based on array values
    stroke(0, 250/i, 110/i);
    strokeWeight(10);
    line(x[i], y[i]-50, x[i], y[i]-20);
    fill(255/i, 150/i, 0);
    noStroke();
    ellipse(x[i], y[i]-1, 20, 75);
    ellipse(x[i]-10, y[i], 30, 75);
    ellipse(x[i]+10, y[i], 30, 75);
    ellipse(x[i]+20, y[i], 50, 75);
    ellipse(x[i]-20, y[i], 50, 75);
    fill(0);
    arc(x[i], y[i], 50, 50, 0, PI, PIE);
    ellipse(x[i]-20, y[i]-20, 10, 10);
    ellipse(x[i]+20, y[i]-20, 10, 10);
  }
  
  // printing length of array x to console
  print(x.length)
}